# AltWheels resource library

Publication destination: https://www.cloudzoom.dev/altwheels/

This standalone static section follows the CloudZoom site's existing HTML structure and branding. All page files and resources live under altwheels/; the existing deployment configuration is unchanged. The related event article is featured on the homepage and blog index.

## Source and editions

The supplied AltWheels_CloudZoom_Resource_Pack.zip was prepared September 30, 2026. It contains the action plan, nine prompts, consolidated prompt pack, three templates, example briefing skill and reference guide. The prompts, templates, skill and reference guide are preserved. The PDF handout is updated with the permanent resource URL and QR code for publication.

The CloudZoom page styling, fleet-tool directory, QR asset and complete ZIP were added October 5, 2026. Directory entries link to official pages checked on that date; they are examples for evaluation, not rankings or endorsements.

## Contents

- index.html: talk page, downloads, copy-ready prompts and templates.
- fleet-tools.html: fleet-tool directory and evaluation questions.
- references.html and REFERENCE_GUIDE.md: original source notes.
- downloads/: action plan PDF, prompt pack, tool directory and complete resource ZIP.
- prompts/: nine original copy-ready text files.
- templates/: original Fleet Brief, Session Handoff and Fleet Data Guide.
- skills/fleet-weekly-briefing/SKILL.md: original instruction-only example, not executed by the site.
- assets/: scoped CSS/JavaScript, existing CloudZoom mark, PDF preview and QR SVG. The Word source is omitted from this publication at the user’s request.

## Local validation and deployment

The repository's npm run build is the existing static-site no-op. Preview the repository root through a local HTTP server and open /altwheels/. Check desktop/mobile layouts, prompt disclosures and copy actions, every local link and download, and the QR destination. The core content and downloads work without JavaScript; copy buttons appear only when clipboard access is available.

Publishing a commit to master triggers the existing Azure Static Web Apps workflow. Verify the production page and download response bodies after deployment. The other pre-existing legacy workflow is outside this change.

To refresh the complete ZIP, archive this directory with a top-level AltWheels_CloudZoom_Resource_Pack/ prefix, excluding the ZIP itself. Test archive integrity before publishing. The ZIP contains an offline copy; CloudZoom navigation and provider links require internet access.
